%PART 1-
%Importing the raw data from JHU Github Repository (1st April-16th November)
%The following code was taught in class to clean and import the data.

disp('Running covid-19 data extraction code');

datestr(now)

sessionstart=datetime('now');

tic
%defining global variables
global abspath datapath scriptpath datasetspath;

%path of the folder
abspath='/MATLAB Drive/';

%path for the raw data from SOOFA
datapath=strcat(abspath,'jhudata/');

%path where the scripts are kept
scriptpath=strcat(abspath,'scripts/');

%path where the results are kept
datasetspath=strcat(abspath,'datasets/');

addpath(scriptpath);
addpath(datapath);
addpath(datasetspath);

s1allFiles = dir(datapath);
s1allFileNames = {s1allFiles.name};

%this has to be done manually to delete the non csv files.
%%%%%%%%manually delete the files such as .,..,.gitignore,READ.md (all files
%except .csv files)
%delete the .csv files till 03-31-2020 as the fields were changing.

% if size(s1allFileNames,2) > 1
%     s1allFileNames=transpose(s1allFileNames);
% end

save('/MATLAB Drive/datasets/covid19FileNames.mat','s1allFileNames');
save(strcat(datasetspath,'test.mat'),'s1allFileNames');

load covid19FileNames.mat;
%% this step appends all the data into one file.
%Part 2- Appending the data in single table so that we can sort the different countries of europe later.
s1numFiles=numel(s1allFileNames);

covid19_data=importfile1(strcat(datapath,s1allFileNames{1}));

for i = 2:s1numFiles

s1FileNamei=s1allFileNames{i};

covid19_data_onefile = importfile1(strcat(datapath,s1FileNamei));

covid19_data=vertcat(covid19_data,covid19_data_onefile);

end

covid19_data2 = convertvars(covid19_data,'Last_Update',@string);

%convert string to datetime variable in a Table
covid19_data2.Last_Update=datetime(covid19_data2.Last_Update,'InputFormat','yyyy-MM-dd HH:mm:ss');

 save('/MATLAB Drive/datasets/covid19_data2.mat','covid19_data2');

datestr(now)

toc

%%Part 3-
%Sorting the data and getting only the data of countries which fall under europe from presaved covid19_data2.mat which include all of it.
%I took help for this code from my friend Navaneeth KP.
%There are 27 countries in europe as follows-

summary(covid19_data2)
countrywise_Austria = covid19_data2(covid19_data2.Country_Region=='Austria',:)
countrywise_Italy = covid19_data2(covid19_data2.Country_Region=='Italy',:)
countrywise_Belgium = covid19_data2(covid19_data2.Country_Region=='Belgium',:)
countrywise_Latvia = covid19_data2(covid19_data2.Country_Region=='Latvia',:)
countrywise_Bulgaria = covid19_data2(covid19_data2.Country_Region=='Bulgaria',:)
countrywise_Lithuania = covid19_data2(covid19_data2.Country_Region=='Lithuania',:)
countrywise_Croatia = covid19_data2(covid19_data2.Country_Region=='Croatia',:)
countrywise_Luxembourg = covid19_data2(covid19_data2.Country_Region=='Luxembourg',:)
countrywise_Cyprus = covid19_data2(covid19_data2.Country_Region=='Cyprus',:)
countrywise_Malta = covid19_data2(covid19_data2.Country_Region=='Malta',:)
countrywise_Czechia = covid19_data2(covid19_data2.Country_Region=='Czechia',:)
countrywise_Netherlands = covid19_data2(covid19_data2.Country_Region=='Netherlands',:)
countrywise_Denmark = covid19_data2(covid19_data2.Country_Region=='Denmark',:)
countrywise_Poland = covid19_data2(covid19_data2.Country_Region=='Poland',:)
countrywise_Estonia = covid19_data2(covid19_data2.Country_Region=='Estonia',:)
countrywise_Portugal = covid19_data2(covid19_data2.Country_Region=='Portugal',:)
countrywise_Finland = covid19_data2(covid19_data2.Country_Region=='Finland',:)
countrywise_Romania = covid19_data2(covid19_data2.Country_Region=='Romania',:)
countrywise_France = covid19_data2(covid19_data2.Country_Region=='France',:)
countrywise_Slovakia = covid19_data2(covid19_data2.Country_Region=='Slovakia',:)
countrywise_Germany = covid19_data2(covid19_data2.Country_Region=='Germany',:)
countrywise_Slovenia = covid19_data2(covid19_data2.Country_Region=='Slovenia',:)
countrywise_Greece = covid19_data2(covid19_data2.Country_Region=='Greece',:)
countrywise_Spain = covid19_data2(covid19_data2.Country_Region=='Spain',:)
countrywise_Hungary = covid19_data2(covid19_data2.Country_Region=='Hungary',:)
countrywise_Sweden = covid19_data2(covid19_data2.Country_Region=='Sweden',:)
countrywise_Ireland = covid19_data2(covid19_data2.Country_Region=='Ireland',:)

%Graph Parameters for Confirmed cases, Deaths and Recovered Cases data-
fcountrywise_Austria= graphparam(countrywise_Austria)
fcountrywise_Italy=graphparam(countrywise_Italy)
fcountrywise_Belgium=graphparam(countrywise_Belgium)
fcountrywise_Latvia=graphparam(countrywise_Latvia)
fcountrywise_Bulgaria=graphparam(countrywise_Bulgaria)
fcountrywise_Lithuania=graphparam(countrywise_Lithuania)
fcountrywise_Croatia=graphparam(countrywise_Croatia)
fcountrywise_Luxembourg=graphparam(countrywise_Luxembourg)
fcountrywise_Cyprus=graphparam(countrywise_Cyprus)
fcountrywise_Malta=graphparam(countrywise_Malta)
fcountrywise_Czechia=graphparam(countrywise_Czechia)
fcountrywise_Netherlands=graphparam(countrywise_Netherlands)
fcountrywise_Denmark=graphparam(countrywise_Denmark)
fcountrywise_Poland=graphparam(countrywise_Poland)
fcountrywise_Estonia=graphparam(countrywise_Estonia)
fcountrywise_Portugal=graphparam(countrywise_Portugal)
fcountrywise_Finland= graphparam(countrywise_Finland)
fcountrywise_Romania =graphparam(countrywise_Romania)
fcountrywise_France=graphparam(countrywise_France)
fcountrywise_Slovakia =graphparam(countrywise_Slovakia)
fcountrywise_Germany=graphparam(countrywise_Germany)
fcountrywise_Slovenia=graphparam(countrywise_Slovenia)
fcountrywise_Greece=cleanUpdates(countrywise_Greece)
fcountrywise_Spain=graphparam(countrywise_Spain)
fcountrywise_Hungary=graphparam(countrywise_Hungary)
fcountrywise_Sweden=graphparam(countrywise_Sweden)
fcountrywise_Ireland=graphparam(countrywise_Ireland)

Eu_database = [fcountrywise_Austria;fcountrywise_Italy;fcountrywise_Belgium;fcountrywise_Latvia;fcountrywise_Bulgaria;fcountrywise_Lithuania;fcountrywise_Croatia;fcountrywise_Luxembourg;fcountrywise_Cyprus;fcountrywise_Malta;fcountrywise_Czechia;fcountrywise_Netherlands;fcountrywise_Denmark;fcountrywise_Poland;fcountrywise_Estonia;fcountrywise_Portugal;fcountrywise_Finland;fcountrywise_Croatia]

Eu_database = sortrows(Eu_database,'Last_Update')

%plot(countrywise_Austria.Last_Update,(countrywise_Austria.Confirmed - countrywise_Austria.Deaths - countrywise_Austria.Recovered))

h=height(Eu_database);
x=table(zeros(h,1),'VariableNames',{'Cases_Active'});
Eu_database_final=[Eu_database,x]

Eu_database_final.Cases_Active(1)=Eu_database_final.Var1(1);

for i=2:h
    Eu_database_final.Cases_Active(i)=Eu_database_final.Cases_Active(i-1)+Eu_database_final.Var1(i);
end

Eu_database_final

%Plotting the graph for EUROPE with time-

plot(Eu_database_final.Last_Update,Eu_database_final.Cases_Active)

%To understand the curve better we smooth the curve-

y=smooth(Eu_database_final.Cases_Active);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
y=smooth(y);
%Final Plot for Analysis using a time series plot for Europe COVID-19
plot(Eu_database_final.Last_Update,y)   